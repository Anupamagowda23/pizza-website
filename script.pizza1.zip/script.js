let cart = [];
let totalPrice = 0;

function addToCart(pizzaName, price) {
    cart.push({ name: pizzaName, price: price });
    totalPrice += price;
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    if (cartItems) {
        cartItems.innerHTML = '';
        cart.forEach(item => {
            const div = document.createElement('div');
            div.className = 'cart-item';
            div.innerHTML = `<p>${item.name} - $${item.price.toFixed(2)}</p>`;
            cartItems.appendChild(div);
        });
        const totalElement = document.getElementById('total-price');
        if (totalElement) {
            totalElement.textContent = `Total: $${totalPrice.toFixed(2)}`;
        }
    } else {
        console.error('Cart items container not found');
    }
}

function checkout() {
    localStorage.setItem('cart', JSON.stringify(cart));
    localStorage.setItem('totalPrice', totalPrice);
    window.location.href = 'checkout.html';
}

function handleCheckoutForm() {
    const form = document.getElementById('checkout-form');
    if (form) {
        form.addEventListener('submit', function(event) {
            event.preventDefault();

            const name = document.getElementById('name').value;
            const date = document.getElementById('date').value;
            const location = document.getElementById('location').value;

            const cartData = JSON.parse(localStorage.getItem('cart')) || [];
            const total = localStorage.getItem('totalPrice') || 0;

            console.log("Cart Data:", cartData);
            console.log("Total Price:", total);

            const summaryItems = document.getElementById('summary-items');
            if (summaryItems) {
                summaryItems.innerHTML = '';
                cartData.forEach(item => {
                    const div = document.createElement('div');
                    div.className = 'summary-item';
                    div.innerHTML = `<p>${item.name} - $${item.price.toFixed(2)}</p>`;
                    summaryItems.appendChild(div);
                });
                const summaryTotal = document.getElementById('summary-total');
                if (summaryTotal) {
                    summaryTotal.textContent = `Total: $${parseFloat(total).toFixed(2)}`;
                }
                const orderDetails = document.getElementById('order-details');
                if (orderDetails) {
                    orderDetails.innerHTML = `
                        <h3>Order Details</h3>
                        <p><strong>Name:</strong> ${name}</p>
                        <p><strong>Date:</strong> ${date}</p>
                        <p><strong>Location:</strong> ${location}</p>
                        <p><strong>Total Price:</strong> $${parseFloat(total).toFixed(2)}</p>
                    `;
                }
            } else {
                console.error('Summary items container not found');
            }

            localStorage.removeItem('cart');
            localStorage.removeItem('totalPrice');

            setTimeout(() => {
                window.location.href = 'index.html';
            }, 3000);
        });
    } else {
        console.error('Checkout form not found');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    if (window.location.pathname.endsWith('checkout.html')) {
        handleCheckoutForm();
        displayOrderSummary();
    }
});

function displayOrderSummary() {
    const cartData = JSON.parse(localStorage.getItem('cart')) || [];
    const total = localStorage.getItem('totalPrice') || 0;

    console.log("Display Order Summary - Cart Data:", cartData);
    console.log("Display Order Summary - Total Price:", total);

    const summaryItems = document.getElementById('summary-items');
    if (summaryItems) {
        summaryItems.innerHTML = '';
        cartData.forEach(item => {
            const div = document.createElement('div');
            div.className = 'summary-item';
            div.innerHTML = `<p>${item.name} - $${item.price.toFixed(2)}</p>`;
            summaryItems.appendChild(div);
        });
        const summaryTotal = document.getElementById('summary-total');
        if (summaryTotal) {
            summaryTotal.textContent = `Total: $${parseFloat(total).toFixed(2)}`;
        }
    } else {
        console.error('Summary items container not found');
    }
}